package com.teamtrack360.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.teamtrack360.app.model.ChatMessage
import com.teamtrack360.app.model.TrailPoint

@Entity(tableName = "trail_points")
data class TrailPointEntity(
    @PrimaryKey(autoGenerate = true) val localId: Long = 0,
    val remoteId: String,
    val uid: String,
    val userName: String,
    val teamCode: String,
    val latitude: Double,
    val longitude: Double,
    val speedMps: Float,
    val batteryPercent: Int,
    val gpsEnabled: Boolean,
    val timestamp: Long,
    val synced: Boolean
) {
    fun toModel() = TrailPoint(
        id = remoteId,
        uid = uid,
        userName = userName,
        teamCode = teamCode,
        latitude = latitude,
        longitude = longitude,
        speedMps = speedMps,
        batteryPercent = batteryPercent,
        gpsEnabled = gpsEnabled,
        timestamp = timestamp,
        synced = synced
    )
}

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val localId: Long = 0,
    val remoteId: String,
    val teamCode: String,
    val senderUid: String,
    val senderName: String,
    val text: String,
    val timestamp: Long,
    val synced: Boolean
) {
    fun toModel() = ChatMessage(
        id = remoteId,
        teamCode = teamCode,
        senderUid = senderUid,
        senderName = senderName,
        text = text,
        timestamp = timestamp,
        synced = synced
    )
}
