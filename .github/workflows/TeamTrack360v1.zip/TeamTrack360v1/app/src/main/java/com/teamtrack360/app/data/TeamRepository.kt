package com.teamtrack360.app.data

import android.content.Context
import android.content.SharedPreferences
import com.google.firebase.FirebaseApp
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.teamtrack360.app.data.local.AppDatabase
import com.teamtrack360.app.data.local.ChatMessageEntity
import com.teamtrack360.app.data.local.TrailPointEntity
import com.teamtrack360.app.model.ChatMessage
import com.teamtrack360.app.model.TeamCircle
import com.teamtrack360.app.model.TrailPoint
import com.teamtrack360.app.model.UserProfile
import com.teamtrack360.app.util.DeviceStatusHelper
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class TeamRepository(private val context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val dao = db.appDao()
    private val prefs: SharedPreferences =
        context.getSharedPreferences("teamtrack360_prefs", Context.MODE_PRIVATE)

    private val _currentUser = MutableStateFlow<UserProfile?>(loadSavedUser())
    val currentUser: StateFlow<UserProfile?> = _currentUser.asStateFlow()

    val isFirebaseReady: Boolean
        get() = try {
            FirebaseApp.getApps(context).isNotEmpty()
        } catch (_: Exception) {
            false
        }

    private fun firebaseDb(): FirebaseDatabase? {
        return if (isFirebaseReady) {
            try {
                FirebaseDatabase.getInstance()
            } catch (_: Exception) {
                null
            }
        } else null
    }

    private fun loadSavedUser(): UserProfile? {
        val uid = prefs.getString("uid", null) ?: return null
        val (battery, charging) = DeviceStatusHelper.getBatteryInfo(context)
        val gpsOn = DeviceStatusHelper.isGpsEnabled(context)
        return UserProfile(
            uid = uid,
            name = prefs.getString("name", "Team Member") ?: "Team Member",
            email = prefs.getString("email", "") ?: "",
            photoUrl = prefs.getString("photoUrl", "") ?: "",
            teamCode = prefs.getString("teamCode", "") ?: "",
            isAdmin = prefs.getBoolean("isAdmin", false),
            canViewOthersLive = prefs.getBoolean("canViewOthersLive", false),
            canViewOthersTrails = prefs.getBoolean("canViewOthersTrails", false),
            canViewOwnTrails = prefs.getBoolean("canViewOwnTrails", true),
            batteryPercent = battery,
            isCharging = charging,
            gpsEnabled = gpsOn,
            gpsTurnedOffAt = prefs.getLong("gpsTurnedOffAt", 0L).takeIf { it > 0L },
            gpsTurnedOnAt = prefs.getLong("gpsTurnedOnAt", 0L).takeIf { it > 0L },
            lastLat = Double.fromBits(prefs.getLong("lastLat", 0.0.toBits())),
            lastLng = Double.fromBits(prefs.getLong("lastLng", 0.0.toBits())),
            lastUpdated = prefs.getLong("lastUpdated", System.currentTimeMillis()),
            isOnline = DeviceStatusHelper.isInternetAvailable(context)
        )
    }

    private fun saveUserLocally(user: UserProfile) {
        prefs.edit()
            .putString("uid", user.uid)
            .putString("name", user.name)
            .putString("email", user.email)
            .putString("photoUrl", user.photoUrl)
            .putString("teamCode", user.teamCode)
            .putBoolean("isAdmin", user.isAdmin)
            .putBoolean("canViewOthersLive", user.canViewOthersLive)
            .putBoolean("canViewOthersTrails", user.canViewOthersTrails)
            .putBoolean("canViewOwnTrails", user.canViewOwnTrails)
            .putLong("gpsTurnedOffAt", user.gpsTurnedOffAt ?: 0L)
            .putLong("gpsTurnedOnAt", user.gpsTurnedOnAt ?: 0L)
            .putLong("lastLat", user.lastLat.toBits())
            .putLong("lastLng", user.lastLng.toBits())
            .putLong("lastUpdated", user.lastUpdated)
            .apply()
        _currentUser.value = user
    }

    suspend fun signInUser(uid: String, name: String, email: String, photoUrl: String) {
        val existing = loadSavedUser()
        val (battery, charging) = DeviceStatusHelper.getBatteryInfo(context)
        val gpsOn = DeviceStatusHelper.isGpsEnabled(context)
        val profile = UserProfile(
            uid = uid,
            name = name,
            email = email,
            photoUrl = photoUrl,
            teamCode = existing?.takeIf { it.uid == uid }?.teamCode ?: "",
            isAdmin = existing?.takeIf { it.uid == uid }?.isAdmin ?: false,
            canViewOthersLive = existing?.takeIf { it.uid == uid }?.canViewOthersLive ?: false,
            canViewOthersTrails = existing?.takeIf { it.uid == uid }?.canViewOthersTrails ?: false,
            canViewOwnTrails = existing?.takeIf { it.uid == uid }?.canViewOwnTrails ?: true,
            batteryPercent = battery,
            isCharging = charging,
            gpsEnabled = gpsOn,
            lastUpdated = System.currentTimeMillis(),
            isOnline = DeviceStatusHelper.isInternetAvailable(context)
        )
        saveUserLocally(profile)
        pushUserProfileToCloud(profile)
    }

    fun signOut() {
        prefs.edit().clear().apply()
        _currentUser.value = null
    }

    suspend fun createTeam(teamName: String): Result<TeamCircle> {
        val user = _currentUser.value ?: return Result.failure(Exception("Not signed in"))
        val code = UUID.randomUUID().toString().replace("-", "").take(6).uppercase()
        val circle = TeamCircle(
            code = code,
            name = teamName.trim().ifEmpty { "My Team Circle" },
            adminUid = user.uid,
            createdAt = System.currentTimeMillis()
        )
        val updatedUser = user.copy(
            teamCode = code,
            isAdmin = true,
            canViewOthersLive = true,
            canViewOthersTrails = true,
            canViewOwnTrails = true
        )
        saveUserLocally(updatedUser)

        firebaseDb()?.let { fb ->
            try {
                fb.getReference("teams/$code/info").setValue(circle).await()
                fb.getReference("teams/$code/members/${user.uid}").setValue(updatedUser).await()
            } catch (_: Exception) {
                // Will sync when online
            }
        }
        return Result.success(circle)
    }

    suspend fun joinTeam(rawCode: String): Result<String> {
        val user = _currentUser.value ?: return Result.failure(Exception("Not signed in"))
        val code = rawCode.trim().uppercase()
        if (code.length < 4) {
            return Result.failure(Exception("Enter a valid invite code"))
        }

        val fb = firebaseDb()
        if (fb != null && DeviceStatusHelper.isInternetAvailable(context)) {
            try {
                val snapshot = fb.getReference("teams/$code/info").get().await()
                if (!snapshot.exists()) {
                    return Result.failure(Exception("Team code '$code' not found"))
                }
            } catch (e: Exception) {
                return Result.failure(e)
            }
        }

        val updatedUser = user.copy(
            teamCode = code,
            isAdmin = false,
            canViewOthersLive = false,
            canViewOthersTrails = false,
            canViewOwnTrails = true
        )
        saveUserLocally(updatedUser)
        pushUserProfileToCloud(updatedUser)
        return Result.success(code)
    }

    suspend fun updateMemberPermissions(
        targetMember: UserProfile,
        canViewOthersLive: Boolean,
        canViewOthersTrails: Boolean,
        canViewOwnTrails: Boolean
    ) {
        val updated = targetMember.copy(
            canViewOthersLive = canViewOthersLive,
            canViewOthersTrails = canViewOthersTrails,
            canViewOwnTrails = canViewOwnTrails
        )
        if (_currentUser.value?.uid == targetMember.uid) {
            saveUserLocally(updated)
        }
        firebaseDb()?.let { fb ->
            if (updated.teamCode.isNotEmpty()) {
                try {
                    fb.getReference("teams/${updated.teamCode}/members/${updated.uid}")
                        .setValue(updated).await()
                } catch (_: Exception) {
                }
            }
        }
    }

    suspend fun recordGpsStateChange(gpsEnabled: Boolean) {
        val user = _currentUser.value ?: return
        if (user.gpsEnabled == gpsEnabled) return
        val now = System.currentTimeMillis()
        val (battery, charging) = DeviceStatusHelper.getBatteryInfo(context)
        val updated = if (!gpsEnabled) {
            user.copy(
                gpsEnabled = false,
                gpsTurnedOffAt = now,
                batteryPercent = battery,
                isCharging = charging,
                lastUpdated = now
            )
        } else {
            user.copy(
                gpsEnabled = true,
                gpsTurnedOnAt = now,
                batteryPercent = battery,
                isCharging = charging,
                lastUpdated = now
            )
        }
        saveUserLocally(updated)
        pushUserProfileToCloud(updated)
    }

    suspend fun recordLocationPoint(lat: Double, lng: Double, speedMps: Float) {
        val user = _currentUser.value ?: return
        val now = System.currentTimeMillis()
        val (battery, charging) = DeviceStatusHelper.getBatteryInfo(context)
        val gpsOn = DeviceStatusHelper.isGpsEnabled(context)
        val online = DeviceStatusHelper.isInternetAvailable(context)

        val updatedUser = user.copy(
            lastLat = lat,
            lastLng = lng,
            batteryPercent = battery,
            isCharging = charging,
            gpsEnabled = gpsOn,
            lastUpdated = now,
            isOnline = online
        )
        saveUserLocally(updatedUser)

        val pointId = UUID.randomUUID().toString()
        val entity = TrailPointEntity(
            remoteId = pointId,
            uid = user.uid,
            userName = user.name,
            teamCode = user.teamCode,
            latitude = lat,
            longitude = lng,
            speedMps = speedMps,
            batteryPercent = battery,
            gpsEnabled = gpsOn,
            timestamp = now,
            synced = false
        )
        dao.insertTrailPoint(entity)

        if (online) {
            syncPendingData()
        }
    }

    suspend fun sendChatMessage(text: String) {
        val user = _currentUser.value ?: return
        if (text.isBlank() || user.teamCode.isBlank()) return

        val now = System.currentTimeMillis()
        val msgId = UUID.randomUUID().toString()
        val entity = ChatMessageEntity(
            remoteId = msgId,
            teamCode = user.teamCode,
            senderUid = user.uid,
            senderName = user.name,
            text = text.trim(),
            timestamp = now,
            synced = false
        )
        dao.insertChatMessage(entity)

        if (DeviceStatusHelper.isInternetAvailable(context)) {
            syncPendingData()
        }
    }

    suspend fun syncPendingData() {
        if (!DeviceStatusHelper.isInternetAvailable(context)) return
        val user = _currentUser.value ?: return
        pushUserProfileToCloud(user)

        val fb = firebaseDb() ?: return

        // 1. Batch upload offline trail points
        val unsyncedTrails = dao.getUnsyncedTrails()
        if (unsyncedTrails.isNotEmpty()) {
            val syncedIds = mutableListOf<Long>()
            for (pt in unsyncedTrails) {
                if (pt.teamCode.isBlank()) continue
                try {
                    val model = pt.toModel().copy(synced = true)
                    fb.getReference("teams/${pt.teamCode}/trails/${pt.uid}/${pt.remoteId}")
                        .setValue(model).await()
                    syncedIds.add(pt.localId)
                } catch (_: Exception) {
                    break
                }
            }
            if (syncedIds.isNotEmpty()) {
                dao.markTrailsSynced(syncedIds)
            }
        }

        // 2. Batch upload offline chat messages
        val unsyncedChats = dao.getUnsyncedMessages()
        if (unsyncedChats.isNotEmpty()) {
            val syncedChatIds = mutableListOf<Long>()
            for (msg in unsyncedChats) {
                if (msg.teamCode.isBlank()) continue
                try {
                    val model = msg.toModel().copy(synced = true)
                    fb.getReference("teams/${msg.teamCode}/chat/${msg.remoteId}")
                        .setValue(model).await()
                    syncedChatIds.add(msg.localId)
                } catch (_: Exception) {
                    break
                }
            }
            if (syncedChatIds.isNotEmpty()) {
                dao.markMessagesSynced(syncedChatIds)
            }
        }
    }

    private suspend fun pushUserProfileToCloud(user: UserProfile) {
        val fb = firebaseDb() ?: return
        if (user.teamCode.isBlank()) return
        try {
            fb.getReference("teams/${user.teamCode}/members/${user.uid}")
                .setValue(user).await()
        } catch (_: Exception) {
        }
    }

    fun observeTeamMembers(teamCode: String): Flow<List<UserProfile>> = callbackFlow {
        val fb = firebaseDb()
        if (fb == null || teamCode.isBlank()) {
            val localUser = _currentUser.value
            trySend(if (localUser != null) listOf(localUser) else emptyList())
            close()
            return@callbackFlow
        }

        val ref = fb.getReference("teams/$teamCode/members")
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = snapshot.children.mapNotNull { it.getValue(UserProfile::class.java) }
                // Keep local user's admin-granted permissions synchronized
                val me = _currentUser.value
                if (me != null) {
                    val remoteMe = list.find { it.uid == me.uid }
                    if (remoteMe != null &&
                        (remoteMe.canViewOthersLive != me.canViewOthersLive ||
                            remoteMe.canViewOthersTrails != me.canViewOthersTrails ||
                            remoteMe.canViewOwnTrails != me.canViewOwnTrails ||
                            remoteMe.isAdmin != me.isAdmin)
                    ) {
                        saveUserLocally(
                            me.copy(
                                isAdmin = remoteMe.isAdmin,
                                canViewOthersLive = remoteMe.canViewOthersLive,
                                canViewOthersTrails = remoteMe.canViewOthersTrails,
                                canViewOwnTrails = remoteMe.canViewOwnTrails
                            )
                        )
                    }
                }
                trySend(list)
            }

            override fun onCancelled(error: DatabaseError) {}
        }
        ref.addValueEventListener(listener)
        awaitClose { ref.removeEventListener(listener) }
    }

    fun observeTeamTrailsFromCloud(teamCode: String): Flow<Map<String, List<TrailPoint>>> = callbackFlow {
        val fb = firebaseDb()
        if (fb == null || teamCode.isBlank()) {
            trySend(emptyMap())
            close()
            return@callbackFlow
        }

        val ref = fb.getReference("teams/$teamCode/trails")
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val result = mutableMapOf<String, List<TrailPoint>>()
                for (userNode in snapshot.children) {
                    val uid = userNode.key ?: continue
                    val points = userNode.children.mapNotNull { it.getValue(TrailPoint::class.java) }
                        .sortedBy { it.timestamp }
                    result[uid] = points
                }
                trySend(result)
            }

            override fun onCancelled(error: DatabaseError) {}
        }
        ref.addValueEventListener(listener)
        awaitClose { ref.removeEventListener(listener) }
    }

    fun observeLocalUserTrails(uid: String): Flow<List<TrailPoint>> {
        return dao.observeUserTrails(uid).map { list -> list.map { it.toModel() } }
    }

    fun observePendingTrailCount(): Flow<Int> = dao.observePendingTrailCount()

    fun observeTeamChat(teamCode: String): Flow<List<ChatMessage>> = callbackFlow {
        val fb = firebaseDb()
        if (fb == null || teamCode.isBlank()) {
            dao.observeTeamChat(teamCode).collect { localList ->
                trySend(localList.map { it.toModel() })
            }
            return@callbackFlow
        }

        val ref = fb.getReference("teams/$teamCode/chat").limitToLast(100)
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val messages = snapshot.children.mapNotNull { it.getValue(ChatMessage::class.java) }
                    .sortedBy { it.timestamp }
                trySend(messages)
            }

            override fun onCancelled(error: DatabaseError) {}
        }
        ref.addValueEventListener(listener)
        awaitClose { ref.removeEventListener(listener) }
    }
}
