package com.teamtrack360.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.teamtrack360.app.ui.MainDashboardScreen
import com.teamtrack360.app.ui.SignInScreen
import com.teamtrack360.app.ui.TeamSetupScreen
import com.teamtrack360.app.ui.TeamViewModel
import java.util.UUID

class MainActivity : ComponentActivity() {

    private val viewModel: TeamViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                val currentUser by viewModel.currentUser.collectAsState()

                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestMultiplePermissions()
                ) { grants ->
                    if (grants[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
                        viewModel.startTrackingService()
                    }
                }

                LaunchedEffect(Unit) {
                    val perms = mutableListOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        perms.add(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    permissionLauncher.launch(perms.toTypedArray())
                }

                val googleSignInLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.StartActivityForResult()
                ) { result ->
                    val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
                    try {
                        val account = task.getResult(ApiException::class.java)
                        val uid = account.id ?: UUID.randomUUID().toString()
                        val name = account.displayName ?: "Google User"
                        val email = account.email ?: ""
                        val photo = account.photoUrl?.toString() ?: ""
                        viewModel.handleGoogleSignIn(uid, name, email, photo)
                    } catch (e: ApiException) {
                        Toast.makeText(
                            this,
                            "Google Sign-In failed (code ${e.statusCode}). Check Firebase SHA-1 / google-services.json.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

                val user = currentUser
                when {
                    user == null -> {
                        SignInScreen(
                            isFirebaseReady = viewModel.isFirebaseReady,
                            onGoogleSignInClick = {
                                val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                                    .requestEmail()
                                    .build()
                                val client = GoogleSignIn.getClient(this, gso)
                                googleSignInLauncher.launch(client.signInIntent)
                            },
                            onOfflineDemoSignIn = { customName ->
                                viewModel.handleGoogleSignIn(
                                    uid = "local_${UUID.randomUUID().toString().take(8)}",
                                    name = customName,
                                    email = "local@teamtrack360.app",
                                    photoUrl = ""
                                )
                            }
                        )
                    }
                    user.teamCode.isBlank() -> {
                        TeamSetupScreen(
                            user = user,
                            onCreateTeam = { viewModel.createTeam(it) },
                            onJoinTeam = { viewModel.joinTeam(it) },
                            onSignOut = { viewModel.signOut() }
                        )
                    }
                    else -> {
                        MainDashboardScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }
}
