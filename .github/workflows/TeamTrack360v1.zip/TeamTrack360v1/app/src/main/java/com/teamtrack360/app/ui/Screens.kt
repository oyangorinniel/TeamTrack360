package com.teamtrack360.app.ui

import android.graphics.Color as AndroidColor
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.teamtrack360.app.model.ChatMessage
import com.teamtrack360.app.model.TrailPoint
import com.teamtrack360.app.model.UserProfile
import com.teamtrack360.app.util.DeviceStatusHelper
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline

@Composable
fun SignInScreen(
    isFirebaseReady: Boolean,
    onGoogleSignInClick: () -> Unit,
    onOfflineDemoSignIn: (String) -> Unit
) {
    var demoName by remember { mutableStateOf("") }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.LocationOn,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(72.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "TeamTrack 360",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "100% Free Family & Team Live Location, Trails, Battery & Chat",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = onGoogleSignInClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.AccountCircle, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Sign in with Google")
            }

            if (!isFirebaseReady) {
                Spacer(modifier = Modifier.height(20.dp))
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Firebase Not Linked Yet (Local Offline Mode)",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "To sync across multiple devices, add google-services.json from a free Firebase Spark project. You can test local GPS & offline trail recording right now below:",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = demoName,
                            onValueChange = { demoName = it },
                            label = { Text("Enter your name to test locally") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        FilledTonalButton(
                            onClick = {
                                onOfflineDemoSignIn(demoName.ifBlank { "Team Admin" })
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Continue in Local Test Mode")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TeamSetupScreen(
    user: UserProfile,
    onCreateTeam: (String) -> Unit,
    onJoinTeam: (String) -> Unit,
    onSignOut: () -> Unit
) {
    var teamName by remember { mutableStateOf("") }
    var inviteCode by remember { mutableStateOf("") }

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Welcome, ${user.name}", style = MaterialTheme.typography.titleLarge)
                IconButton(onClick = onSignOut) {
                    Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = "Sign out")
                }
            }
            Spacer(modifier = Modifier.height(24.dp))

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Create a New Team / Circle", fontWeight = FontWeight.Bold)
                    Text(
                        "You will be the Admin and can see all live locations, trails, battery levels, and manage member permissions.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = teamName,
                        onValueChange = { teamName = it },
                        label = { Text("Team or Family Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { onCreateTeam(teamName) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Create Circle (As Admin)")
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Join Existing Team / Circle", fontWeight = FontWeight.Bold)
                    Text(
                        "Enter the 6-character invite code shared by your Admin.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = inviteCode,
                        onValueChange = { inviteCode = it.uppercase() },
                        label = { Text("Invite Code (e.g. A1B2C3)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedButton(
                        onClick = { onJoinTeam(inviteCode) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Join Circle")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainDashboardScreen(viewModel: TeamViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val members by viewModel.teamMembers.collectAsState()
    val cloudTrails by viewModel.cloudTrails.collectAsState()
    val localOwnTrails by viewModel.localOwnTrails.collectAsState()
    val chatMessages by viewModel.chatMessages.collectAsState()
    val pendingOfflineCount by viewModel.pendingOfflineCount.collectAsState()
    val selectedTrailUid by viewModel.selectedTrailUserUid.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) }
    val user = currentUser ?: return

    LaunchedEffect(Unit) {
        viewModel.startTrackingService()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("TeamTrack 360", fontWeight = FontWeight.Bold)
                        Text(
                            text = "Code: ${user.teamCode} • ${if (user.isAdmin) "Admin" else "Member"}",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                },
                actions = {
                    if (pendingOfflineCount > 0) {
                        AssistChip(
                            onClick = { viewModel.syncNow() },
                            label = { Text("Offline Queue: $pendingOfflineCount") }
                        )
                    }
                    IconButton(onClick = { viewModel.syncNow() }) {
                        Icon(Icons.Default.Sync, contentDescription = "Sync now")
                    }
                    IconButton(onClick = { viewModel.signOut() }) {
                        Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = "Sign Out")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Map, contentDescription = "Live Map") },
                    label = { Text("Live Map") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Timeline, contentDescription = "Trails") },
                    label = { Text("Trails") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Group, contentDescription = "Members") },
                    label = { Text("Members") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.Chat, contentDescription = "Chat") },
                    label = { Text("Chat") }
                )
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            statusMessage?.let { msg ->
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(msg, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                        TextButton(onClick = { viewModel.clearStatusMessage() }) {
                            Text("OK")
                        }
                    }
                }
            }

            when (selectedTab) {
                0 -> LiveMapTab(
                    currentUser = user,
                    members = members,
                    cloudTrails = cloudTrails,
                    localOwnTrails = localOwnTrails,
                    selectedTrailUid = selectedTrailUid ?: user.uid
                )
                1 -> TrailsTab(
                    currentUser = user,
                    members = members,
                    cloudTrails = cloudTrails,
                    localOwnTrails = localOwnTrails,
                    selectedTrailUid = selectedTrailUid ?: user.uid,
                    onSelectMember = {
                        viewModel.selectTrailUser(it)
                        selectedTab = 0
                    }
                )
                2 -> MembersTab(
                    currentUser = user,
                    members = members,
                    onUpdatePermissions = { target, live, trails, own ->
                        viewModel.updateMemberPermissions(target, live, trails, own)
                    }
                )
                3 -> ChatTab(
                    currentUser = user,
                    messages = chatMessages,
                    onSendMessage = { viewModel.sendChat(it) }
                )
            }
        }
    }
}

@Composable
fun LiveMapTab(
    currentUser: UserProfile,
    members: List<UserProfile>,
    cloudTrails: Map<String, List<TrailPoint>>,
    localOwnTrails: List<TrailPoint>,
    selectedTrailUid: String
) {
    val visibleMembers = remember(currentUser, members) {
        if (currentUser.isAdmin || currentUser.canViewOthersLive) {
            members.ifEmpty { listOf(currentUser) }
        } else {
            listOf(currentUser)
        }
    }

    val activeTrail: List<TrailPoint> = remember(currentUser, cloudTrails, localOwnTrails, selectedTrailUid) {
        val isOwn = selectedTrailUid == currentUser.uid
        val allowed = when {
            currentUser.isAdmin -> true
            isOwn -> currentUser.canViewOwnTrails
            else -> currentUser.canViewOthersTrails
        }
        if (!allowed) emptyList()
        else {
            val remote = cloudTrails[selectedTrailUid].orEmpty()
            if (isOwn && remote.isEmpty()) localOwnTrails else remote
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                MapView(ctx).apply {
                    setTileSource(TileSourceFactory.MAPNIK)
                    setMultiTouchControls(true)
                    controller.setZoom(16.0)
                    controller.setCenter(GeoPoint(14.5869, 121.1200))
                }
            },
            update = { mapView ->
                mapView.overlays.clear()

                // Draw GPS trail polyline
                if (activeTrail.size >= 2) {
                    val polyline = Polyline().apply {
                        outlinePaint.color = AndroidColor.BLUE
                        outlinePaint.strokeWidth = 10f
                        setPoints(activeTrail.map { GeoPoint(it.latitude, it.longitude) })
                    }
                    mapView.overlays.add(polyline)
                }

                // Draw member markers with Battery & GPS status
                var focusPoint: GeoPoint? = null
                for (m in visibleMembers) {
                    if (m.lastLat == 0.0 && m.lastLng == 0.0) continue
                    val gp = GeoPoint(m.lastLat, m.lastLng)
                    if (m.uid == currentUser.uid || focusPoint == null) {
                        focusPoint = gp
                    }
                    val gpsNote = if (m.gpsEnabled) {
                        "GPS ON"
                    } else {
                        "GPS OFF at ${DeviceStatusHelper.formatTimestamp(m.gpsTurnedOffAt)}"
                    }
                    val marker = Marker(mapView).apply {
                        position = gp
                        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                        title = "${m.name} (${m.batteryPercent}%)"
                        snippet = "$gpsNote • Updated ${DeviceStatusHelper.formatShortTime(m.lastUpdated)}"
                    }
                    mapView.overlays.add(marker)
                }

                focusPoint?.let {
                    mapView.controller.animateTo(it)
                }
                mapView.invalidate()
            }
        )

        // Top overlay banner showing live permissions & GPS status
        Card(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(12.dp)
                .fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = if (currentUser.isAdmin || currentUser.canViewOthersLive)
                        "Viewing Live Locations (${visibleMembers.size} members)"
                    else
                        "Viewing Own Location Only (Admin controls team visibility)",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
                if (!currentUser.gpsEnabled) {
                    Text(
                        text = "WARNING: Your GPS turned OFF at ${DeviceStatusHelper.formatTimestamp(currentUser.gpsTurnedOffAt)}",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

@Composable
fun TrailsTab(
    currentUser: UserProfile,
    members: List<UserProfile>,
    cloudTrails: Map<String, List<TrailPoint>>,
    localOwnTrails: List<TrailPoint>,
    selectedTrailUid: String,
    onSelectMember: (String) -> Unit
) {
    val allMembers = members.ifEmpty { listOf(currentUser) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("GPS Trail History", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                "Tap a permitted member to draw their route on the Live Map.",
                style = MaterialTheme.typography.bodySmall
            )
        }

        items(allMembers) { member ->
            val isOwn = member.uid == currentUser.uid
            val permitted = when {
                currentUser.isAdmin -> true
                isOwn -> currentUser.canViewOwnTrails
                else -> currentUser.canViewOthersTrails
            }
            val pts = if (isOwn && cloudTrails[member.uid].isNullOrEmpty()) {
                localOwnTrails
            } else {
                cloudTrails[member.uid].orEmpty()
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (selectedTrailUid == member.uid)
                        MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isOwn) "${member.name} (You)" else member.name,
                            fontWeight = FontWeight.Bold
                        )
                        if (permitted) {
                            FilledTonalButton(onClick = { onSelectMember(member.uid) }) {
                                Text("Show on Map (${pts.size} pts)")
                            }
                        } else {
                            Text(
                                "Restricted by Admin",
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }

                    if (permitted && pts.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        val recent = pts.takeLast(5).reversed()
                        for (pt in recent) {
                            Text(
                                text = "• ${DeviceStatusHelper.formatTimestamp(pt.timestamp)} | (${"%.5f".format(pt.latitude)}, ${"%.5f".format(pt.longitude)}) | Bat: ${pt.batteryPercent}% ${if (!pt.synced) "[Offline]" else ""}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    } else if (permitted) {
                        Text("No GPS points recorded yet.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
fun MembersTab(
    currentUser: UserProfile,
    members: List<UserProfile>,
    onUpdatePermissions: (UserProfile, Boolean, Boolean, Boolean) -> Unit
) {
    val allMembers = members.ifEmpty { listOf(currentUser) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Circle Members & Status", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                "Share Invite Code: ${currentUser.teamCode}",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary
            )
        }

        items(allMembers) { member ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "${member.name} ${if (member.isAdmin) "(Admin)" else ""}",
                                fontWeight = FontWeight.Bold
                            )
                            Text(member.email, style = MaterialTheme.typography.bodySmall)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (member.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryStd,
                                contentDescription = "Battery",
                                tint = if (member.batteryPercent <= 20) Color.Red else Color(0xFF2E7D32)
                            )
                            Text("${member.batteryPercent}%", fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // GPS On/Off Status & Exact Turn-Off Timestamp
                    if (member.gpsEnabled) {
                        Text(
                            text = "GPS Status: ON (Active)",
                            color = Color(0xFF2E7D32),
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    } else {
                        Text(
                            text = "GPS Status: TURNED OFF at ${DeviceStatusHelper.formatTimestamp(member.gpsTurnedOffAt)}",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = "Last Seen: ${DeviceStatusHelper.formatTimestamp(member.lastUpdated)}",
                        style = MaterialTheme.typography.bodySmall
                    )

                    // Admin Permission Controls
                    if (currentUser.isAdmin && !member.isAdmin) {
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                        Text("Admin Permissions", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelLarge)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Can view others' live locations", style = MaterialTheme.typography.bodySmall)
                            Switch(
                                checked = member.canViewOthersLive,
                                onCheckedChange = {
                                    onUpdatePermissions(member, it, member.canViewOthersTrails, member.canViewOwnTrails)
                                }
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Can view others' GPS trails", style = MaterialTheme.typography.bodySmall)
                            Switch(
                                checked = member.canViewOthersTrails,
                                onCheckedChange = {
                                    onUpdatePermissions(member, member.canViewOthersLive, it, member.canViewOwnTrails)
                                }
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Can review own previous trails", style = MaterialTheme.typography.bodySmall)
                            Switch(
                                checked = member.canViewOwnTrails,
                                onCheckedChange = {
                                    onUpdatePermissions(member, member.canViewOthersLive, member.canViewOthersTrails, it)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChatTab(
    currentUser: UserProfile,
    messages: List<ChatMessage>,
    onSendMessage: (String) -> Unit
) {
    var draft by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (messages.isEmpty()) {
                item {
                    Text(
                        "No messages yet. Say hello to your circle! Offline messages auto-send when internet returns.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
            items(messages) { msg ->
                val isMine = msg.senderUid == currentUser.uid
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = if (isMine) Alignment.End else Alignment.Start
                ) {
                    Text(
                        text = "${msg.senderName} • ${DeviceStatusHelper.formatShortTime(msg.timestamp)}",
                        style = MaterialTheme.typography.labelSmall
                    )
                    Surface(
                        color = if (isMine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = msg.text,
                            color = if (isMine) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = draft,
                onValueChange = { draft = it },
                placeholder = { Text("Message circle...") },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = {
                    if (draft.isNotBlank()) {
                        onSendMessage(draft)
                        draft = ""
                    }
                }
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
            }
        }
    }
}
