package com.teamtrack360.app

import android.app.Application
import android.preference.PreferenceManager
import com.google.firebase.FirebaseApp
import org.osmdroid.config.Configuration

class TeamTrackApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Initialize OSMdroid user agent so OpenStreetMap tiles load reliably
        Configuration.getInstance().load(
            applicationContext,
            PreferenceManager.getDefaultSharedPreferences(applicationContext)
        )
        Configuration.getInstance().userAgentValue = packageName

        // Safely initialize Firebase if google-services.json was bundled
        try {
            if (FirebaseApp.getApps(this).isEmpty()) {
                FirebaseApp.initializeApp(this)
            }
        } catch (_: Exception) {
            // App runs in Local/Offline-Ready mode if Firebase is not yet configured
        }
    }
}
