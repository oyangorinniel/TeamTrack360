package com.teamtrack360.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrailPoint(point: TrailPointEntity): Long

    @Query("SELECT * FROM trail_points WHERE uid = :uid ORDER BY timestamp ASC")
    fun observeUserTrails(uid: String): Flow<List<TrailPointEntity>>

    @Query("SELECT * FROM trail_points WHERE teamCode = :teamCode ORDER BY timestamp ASC")
    fun observeTeamTrails(teamCode: String): Flow<List<TrailPointEntity>>

    @Query("SELECT * FROM trail_points WHERE synced = 0 ORDER BY timestamp ASC")
    suspend fun getUnsyncedTrails(): List<TrailPointEntity>

    @Query("UPDATE trail_points SET synced = 1 WHERE localId IN (:ids)")
    suspend fun markTrailsSynced(ids: List<Long>)

    @Query("SELECT COUNT(*) FROM trail_points WHERE synced = 0")
    fun observePendingTrailCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChatMessage(message: ChatMessageEntity): Long

    @Query("SELECT * FROM chat_messages WHERE teamCode = :teamCode ORDER BY timestamp ASC")
    fun observeTeamChat(teamCode: String): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages WHERE synced = 0 ORDER BY timestamp ASC")
    suspend fun getUnsyncedMessages(): List<ChatMessageEntity>

    @Query("UPDATE chat_messages SET synced = 1 WHERE localId IN (:ids)")
    suspend fun markMessagesSynced(ids: List<Long>)
}
