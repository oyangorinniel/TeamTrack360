package com.teamtrack360.app.ui

import android.app.Application
import android.content.Intent
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.teamtrack360.app.data.TeamRepository
import com.teamtrack360.app.model.ChatMessage
import com.teamtrack360.app.model.TrailPoint
import com.teamtrack360.app.model.UserProfile
import com.teamtrack360.app.service.LocationTrackingService
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class TeamViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = TeamRepository(application)

    val currentUser: StateFlow<UserProfile?> = repository.currentUser
    val isFirebaseReady: Boolean = repository.isFirebaseReady

    private val _selectedTrailUserUid = MutableStateFlow<String?>(null)
    val selectedTrailUserUid: StateFlow<String?> = _selectedTrailUserUid.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    val pendingOfflineCount: StateFlow<Int> = repository.observePendingTrailCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val teamMembers: StateFlow<List<UserProfile>> = currentUser.flatMapLatest { user ->
        if (user == null || user.teamCode.isBlank()) flowOf(emptyList())
        else repository.observeTeamMembers(user.teamCode)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cloudTrails: StateFlow<Map<String, List<TrailPoint>>> = currentUser.flatMapLatest { user ->
        if (user == null || user.teamCode.isBlank()) flowOf(emptyMap())
        else repository.observeTeamTrailsFromCloud(user.teamCode)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    val localOwnTrails: StateFlow<List<TrailPoint>> = currentUser.flatMapLatest { user ->
        if (user == null) flowOf(emptyList())
        else repository.observeLocalUserTrails(user.uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val chatMessages: StateFlow<List<ChatMessage>> = currentUser.flatMapLatest { user ->
        if (user == null || user.teamCode.isBlank()) flowOf(emptyList())
        else repository.observeTeamChat(user.teamCode)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun handleGoogleSignIn(uid: String, name: String, email: String, photoUrl: String) {
        viewModelScope.launch {
            repository.signInUser(uid, name, email, photoUrl)
            _selectedTrailUserUid.value = uid
        }
    }

    fun signOut() {
        stopTrackingService()
        repository.signOut()
    }

    fun createTeam(name: String) {
        viewModelScope.launch {
            val res = repository.createTeam(name)
            res.onSuccess {
                _statusMessage.value = "Created team! Share code: ${it.code}"
                startTrackingService()
            }.onFailure {
                _statusMessage.value = it.message
            }
        }
    }

    fun joinTeam(code: String) {
        viewModelScope.launch {
            val res = repository.joinTeam(code)
            res.onSuccess {
                _statusMessage.value = "Joined team $it"
                startTrackingService()
            }.onFailure {
                _statusMessage.value = it.message
            }
        }
    }

    fun startTrackingService() {
        val ctx = getApplication<Application>()
        val intent = Intent(ctx, LocationTrackingService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(intent)
        } else {
            ctx.startService(intent)
        }
    }

    fun stopTrackingService() {
        val ctx = getApplication<Application>()
        ctx.stopService(Intent(ctx, LocationTrackingService::class.java))
    }

    fun selectTrailUser(uid: String) {
        _selectedTrailUserUid.value = uid
    }

    fun updateMemberPermissions(
        member: UserProfile,
        canViewOthersLive: Boolean,
        canViewOthersTrails: Boolean,
        canViewOwnTrails: Boolean
    ) {
        viewModelScope.launch {
            repository.updateMemberPermissions(
                member,
                canViewOthersLive,
                canViewOthersTrails,
                canViewOwnTrails
            )
            _statusMessage.value = "Updated permissions for ${member.name}"
        }
    }

    fun sendChat(text: String) {
        viewModelScope.launch {
            repository.sendChatMessage(text)
        }
    }

    fun syncNow() {
        viewModelScope.launch {
            repository.syncPendingData()
            _statusMessage.value = "Synced offline trails & messages"
        }
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }
}
