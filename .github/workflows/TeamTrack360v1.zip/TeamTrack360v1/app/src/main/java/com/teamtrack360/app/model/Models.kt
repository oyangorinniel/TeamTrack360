package com.teamtrack360.app.model

data class UserProfile(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val photoUrl: String = "",
    val teamCode: String = "",
    val isAdmin: Boolean = false,
    val canViewOthersLive: Boolean = false,
    val canViewOthersTrails: Boolean = false,
    val canViewOwnTrails: Boolean = true,
    val batteryPercent: Int = 100,
    val isCharging: Boolean = false,
    val gpsEnabled: Boolean = true,
    val gpsTurnedOffAt: Long? = null,
    val gpsTurnedOnAt: Long? = null,
    val lastLat: Double = 0.0,
    val lastLng: Double = 0.0,
    val lastUpdated: Long = System.currentTimeMillis(),
    val isOnline: Boolean = true
)

data class TeamCircle(
    val code: String = "",
    val name: String = "",
    val adminUid: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class TrailPoint(
    val id: String = "",
    val uid: String = "",
    val userName: String = "",
    val teamCode: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val speedMps: Float = 0f,
    val batteryPercent: Int = 100,
    val gpsEnabled: Boolean = true,
    val timestamp: Long = System.currentTimeMillis(),
    val synced: Boolean = false
)

data class ChatMessage(
    val id: String = "",
    val teamCode: String = "",
    val senderUid: String = "",
    val senderName: String = "",
    val text: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val synced: Boolean = false
)
